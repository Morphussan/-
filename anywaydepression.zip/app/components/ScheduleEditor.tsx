'use client';

import { useState, useEffect } from 'react';
import { Calendar, Clock, Edit, Save, X, Plus, Trash2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { lessonService } from '../api';
import { Lesson as ApiLesson } from '../api/types';

// Типы данных
type DayOfWeek = 'Понедельник' | 'Вторник' | 'Среда' | 'Четверг' | 'Пятница' | 'Суббота';
type LessonTime = { start: string; end: string };
type WeekType = 'current' | 'next';

// Маппинг индекса урока во временной интервал
const indexToTimeMap: Record<string, Record<number, LessonTime>> = {
  "Понедельник": {
    0: { start: '08:40', end: '08:55' },
    1: { start: '09:00', end: '09:40' },
    2: { start: '09:50', end: '11:00' },
    3: { start: '11:30', end: '12:40' },
    4: { start: '13:00', end: '14:10' },
    5: { start: '14:20', end: '15:30' },
    6: { start: '15:40', end: '16:50' },
    7: { start: '17:00', end: '18:00' },
  },
  "Вторник": {
    1: { start: '08:30', end: '09:40' },
    2: { start: '09:50', end: '11:00' },
    3: { start: '11:30', end: '12:40' },
    4: { start: '13:00', end: '14:10' },
    5: { start: "14:20", end: "15:30" },
    6: { start: '15:40', end: '16:50' },
    7: { start: '17:00', end: '18:00' },
  },
  "Среда": {
    1: { start: '08:30', end: '09:40' },
    2: { start: '09:50', end: '11:00' },
    3: { start: '11:30', end: '12:40' },
    4: { start: '13:00', end: '14:10' },
    5: { start: "14:20", end: "15:30" },
    6: { start: '15:40', end: '16:50' },
    7: { start: '17:00', end: '18:00' },
  },
  "Четверг": {
    1: { start: '08:30', end: '09:30' },
    2: { start: '09:40', end: '10:40' },
    3: { start: '11:10', end: '12:10' },
    4: { start: '12:30', end: '13:30' },
    5: { start: '14:40', end: '15:40' },
    6: { start: "15:50", end: "16:50" },
    7: { start: '17:00', end: '18:00' },
  },
  "Пятница": {
    1: { start: '08:30', end: '09:40' },
    2: { start: '09:50', end: '11:00' },
    3: { start: '11:30', end: '12:40' },
    4: { start: '13:00', end: '14:10' },
    5: { start: "14:20", end: "15:30" },
    6: { start: '15:40', end: '16:50' },
    7: { start: '17:00', end: '18:00' },
  },
  "Суббота": {
    1: { start: '08:30', end: '09:30' },
    2: { start: '09:40', end: '10:40' },
    3: { start: '11:00', end: '12:00' },
    4: { start: '12:20', end: '13:20' },
    5: { start: '13:30', end: '14:30' },
    6: { start: "14:40", end: "15:40" },
    7: { start: '16:00', end: '17:00' },
  }
};

// Список всех возможных временных интервалов для уроков
const lessonTimes: LessonTime[] = [
  { start: '08:30', end: '09:40' },
  { start: '09:00', end: '09:40' },
  { start: '09:50', end: '11:00' },
  { start: '11:00', end: '12:00' },
  { start: '11:30', end: '12:40' },
  { start: '12:20', end: '13:20' },
  { start: '13:00', end: '14:10' },
  { start: '13:30', end: '14:30' },
  { start: '14:20', end: '15:30' },
  { start: '14:40', end: '15:40' },
  { start: '15:40', end: '16:50' },
  { start: '15:50', end: '16:50' },
  { start: '17:00', end: '18:00' },
];

// Локальный тип для урока в UI
type Lesson = {
  id: string;
  subject: string;
  teacher: string;
  classroom: string;
  time: LessonTime;
  index: number;
};

type ScheduleDay = {
  day: DayOfWeek;
  lessons: Lesson[];
};

interface ScheduleEditorProps {
  group: string;
  week: WeekType;
}

// Функция для преобразования API уроков в структуру для UI
const transformApiLessonsToSchedule = (lessons: ApiLesson[]): ScheduleDay[] => {
  const days: DayOfWeek[] = ['Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота'];

  // Инициализируем пустое расписание для всех дней
  const schedule: ScheduleDay[] = days.map(day => ({ day, lessons: [] }));

  // Распределяем уроки по дням
  lessons.forEach(apiLesson => {
    const dayIndex = days.findIndex(day => day === apiLesson.day);
    if (dayIndex !== -1) {
      const timeIndex = apiLesson.index;
      const time = indexToTimeMap[apiLesson.day][timeIndex]; // Fallback to first lesson time

      const lesson: Lesson = {
        id: apiLesson.id,
        subject: apiLesson.name,
        teacher: apiLesson.teacher,
        classroom: apiLesson.cabinet,
        time: time,
        index: apiLesson.index
      };

      schedule[dayIndex].lessons.push(lesson);
    }
  });

  // Сортируем уроки в каждом дне по времени
  schedule.forEach(day => {
    day.lessons.sort((a, b) => a.index - b.index);
  });

  return schedule;
};

// Функция для преобразования UI урока в API урок для сохранения
const transformLessonToApi = (lesson: Lesson, groupName: string): Omit<ApiLesson, 'id' | 'group'> & { time: LessonTime } => {
  // Определяем индекс урока на основе времени
  let lessonIndex = 1; // По умолчанию первый урок

  // Находим индекс урока по времени
  for (const dayName in indexToTimeMap) {
    const timesForDay = indexToTimeMap[dayName];
    for (const [index, timeObj] of Object.entries(timesForDay)) {
      if (timeObj.start === lesson.time.start && timeObj.end === lesson.time.end) {
        lessonIndex = Number(index);
        break;
      }
    }
  }

  return {
    name: lesson.subject,
    teacher: lesson.teacher,
    cabinet: lesson.classroom,
    day: '', // Заполняется при сохранении
    index: lessonIndex,
    time: lesson.time // Передаем время пары в API
  };
};

export default function ScheduleEditor({ group, week }: ScheduleEditorProps) {
  const [schedule, setSchedule] = useState<ScheduleDay[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingLesson, setEditingLesson] = useState<{ dayIndex: number; lessonIndex: number } | null>(null);
  const [tempLesson, setTempLesson] = useState<Lesson | null>(null);
  const [isAddingLesson, setIsAddingLesson] = useState(false);
  const [addingToDay, setAddingToDay] = useState<number | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [subjects, setSubjects] = useState<string[]>([]);
  const [loadingSubjects, setLoadingSubjects] = useState(false);
  const [teachers, setTeachers] = useState<string[]>([]);
  const [loadingTeachers, setLoadingTeachers] = useState(false);

  // Состояния для отслеживания изменений
  const [addedLessons, setAddedLessons] = useState<Lesson[]>([]);
  const [updatedLessons, setUpdatedLessons] = useState<Lesson[]>([]);
  const [deletedLessonIds, setDeletedLessonIds] = useState<string[]>([]);

  // Загрузка расписания при выборе группы или изменении недели
  useEffect(() => {
    if (group) {
      setLoading(true);
      setError(null);

      lessonService.getLessonsByGroup(group)
        .then(response => {
          if (response) {
            const transformedSchedule = transformApiLessonsToSchedule(response);
            setSchedule(transformedSchedule);
          } else {
            setError('Не удалось загрузить расписание');
          }
        })
        .catch(err => {
          console.error('Ошибка при загрузке расписания:', err);
          setError('Ошибка при загрузке расписания. Пожалуйста, попробуйте позже.');
        })
        .finally(() => {
          setLoading(false);
        });
    }
  }, [group, week]);

  // Загрузка списка предметов
  const fetchSubjectsList = async () => {
    if (!group) return;

    setLoadingSubjects(true);
    try {
      const response = await lessonService.getLessonList(group);
      if (response) {
        setSubjects(response);
      } else {
        console.error('Ошибка при загрузке списка предметов');
        // Используем пустой массив для отображения вместо ошибки
        setSubjects([]);
      }
    } catch (err) {
      console.error('Ошибка при загрузке списка предметов:', err);
      setSubjects([]);
    } finally {
      setLoadingSubjects(false);
    }
  };

  // Загрузка списка преподавателей
  const fetchTeachersList = async () => {
    if (!group) return;

    setLoadingTeachers(true);
    try {
      const response = await lessonService.getTeacherList(group);
      if (response && response) {
        setTeachers(response);
      } else {
        console.error('Ошибка при загрузке списка преподавателей');
        // Используем пустой массив для отображения вместо ошибки
        setTeachers([]);
      }
    } catch (err) {
      console.error('Ошибка при загрузке списка преподавателей:', err);
      setTeachers([]);
    } finally {
      setLoadingTeachers(false);
    }
  };

  // Начать редактирование занятия
  const handleEditLesson = (dayIndex: number, lessonIndex: number) => {
    setEditingLesson({ dayIndex, lessonIndex });
    setTempLesson({ ...schedule[dayIndex].lessons[lessonIndex] });
    // Загружаем список предметов и преподавателей при открытии модального окна
    fetchSubjectsList();
    fetchTeachersList();
  };

  // Сохранить изменения занятия
  const handleSaveLesson = async () => {
    if (editingLesson && tempLesson) {
      const { dayIndex, lessonIndex } = editingLesson;

      // Индикатор загрузки
      setIsSaving(true);

      try {
        // Подготавливаем данные для API
        const apiLessonData = transformLessonToApi(tempLesson, group);
        apiLessonData.day = schedule[dayIndex].day;

        // Обновляем урок через API
        const response = await lessonService.updateLesson(
          tempLesson.id,
          apiLessonData,
          {} // session
        );

        if (response) {
          // Обновляем локальное состояние
          const newSchedule = [...schedule];
          newSchedule[dayIndex].lessons[lessonIndex] = tempLesson;
          setSchedule(newSchedule);

          // Добавляем урок в список обновленных (или обновляем его, если он уже там)
          setUpdatedLessons(prev => {
            const filtered = prev.filter(lesson => lesson.id !== tempLesson.id);
            return [...filtered, tempLesson];
          });

          setSaveSuccess(true);
          setTimeout(() => setSaveSuccess(false), 3000);

          setEditingLesson(null);
          setTempLesson(null);
        } else {
          setError('Не удалось сохранить изменения');
        }
      } catch (err) {
        console.error('Ошибка при сохранении урока:', err);
        setError('Ошибка при сохранении урока. Пожалуйста, попробуйте позже.');
      } finally {
        setIsSaving(false);
      }
    }
  };

  // Отменить редактирование занятия
  const handleCancelEdit = () => {
    setEditingLesson(null);
    setTempLesson(null);
  };

  // Начать добавление нового занятия
  const handleAddLesson = (dayIndex: number) => {
    setIsAddingLesson(true);
    setAddingToDay(dayIndex);
    setTempLesson({
      id: `new-${Date.now()}`,
      subject: '',
      teacher: '',
      classroom: '',
      time: lessonTimes[0],
      index: 1 // Добавляем индекс по умолчанию
    });
    // Загружаем список предметов и преподавателей при открытии модального окна
    fetchSubjectsList();
    fetchTeachersList();
  };

  // Сохранить новое занятие
  const handleSaveNewLesson = async () => {
    if (addingToDay !== null && tempLesson) {

      // Индикатор загрузки
      setIsSaving(true);

      try {
        // Подготавливаем данные для API
        const apiLessonData = transformLessonToApi(tempLesson, group);
        apiLessonData.day = schedule[addingToDay].day;

        // Создаем урок через API
        const response = await lessonService.createLesson(
          {
            ...apiLessonData,
            group: { id: '', name: group, discipline: '' } // Заполняем минимально необходимую информацию о группе
          },
          {} // session
        );

        if (response) {
          // Обновляем локальное состояние с новым id
          const updatedLesson = {
            ...tempLesson,
            id: response.id || tempLesson.id // Используем id из ответа или существующий id
          };

          const newSchedule = [...schedule];
          newSchedule[addingToDay].lessons.push(updatedLesson);
          // Сортируем занятия по времени начала
          newSchedule[addingToDay].lessons.sort((a, b) => a.time.start.localeCompare(b.time.start));
          setSchedule(newSchedule);

          // Добавляем новый урок в список добавленных
          setAddedLessons(prev => [...prev, updatedLesson]);

          setSaveSuccess(true);
          setTimeout(() => setSaveSuccess(false), 3000);

          setIsAddingLesson(false);
          setAddingToDay(null);
          setTempLesson(null);
        } else {
          setError('Не удалось создать урок');
        }
      } catch (err) {
        console.error('Ошибка при создании урока:', err);
        setError('Ошибка при создании урока. Пожалуйста, попробуйте позже.');
      } finally {
        setIsSaving(false);
      }
    }
  };

  // Отменить добавление занятия
  const handleCancelAdd = () => {
    setIsAddingLesson(false);
    setAddingToDay(null);
    setTempLesson(null);
  };

  // Удалить занятие
  const handleDeleteLesson = async (dayIndex: number, lessonIndex: number) => {
    const lessonId = schedule[dayIndex].lessons[lessonIndex].id;

    // Индикатор загрузки
    setIsSaving(true);

    try {
      // Удаляем урок через API
      const response = await lessonService.deleteLesson(lessonId, {});

      if (response.success) {
        // Обновляем локальное состояние
        const newSchedule = [...schedule];
        const removedLesson = newSchedule[dayIndex].lessons[lessonIndex];
        newSchedule[dayIndex].lessons.splice(lessonIndex, 1);
        setSchedule(newSchedule);

        // Добавляем id урока в список удаленных
        setDeletedLessonIds(prev => [...prev, lessonId]);

        // Если урок был ранее добавлен, удаляем его из списка добавленных
        setAddedLessons(prev => prev.filter(lesson => lesson.id !== lessonId));

        // Если урок был ранее обновлен, удаляем его из списка обновленных
        setUpdatedLessons(prev => prev.filter(lesson => lesson.id !== lessonId));

        setSaveSuccess(true);
        setTimeout(() => setSaveSuccess(false), 3000);
      } else {
        setError(response.error || 'Не удалось удалить урок');
      }
    } catch (err) {
      console.error('Ошибка при удалении урока:', err);
      setError('Ошибка при удалении урока. Пожалуйста, попробуйте позже.');
    } finally {
      setIsSaving(false);
    }
  };

  // Сохранить все расписание
  const handleSaveSchedule = async () => {
    setIsSaving(true);
    setError(null);

    try {
      // Формируем данные для API в соответствии с согласованной структурой
      const changes = {
        added: addedLessons.map(lesson => ({
          subject: lesson.subject,
          teacher: lesson.teacher,
          classroom: lesson.classroom,
          day: schedule.find(day =>
            day.lessons.some(l => l.id === lesson.id)
          )?.day || '',
          index: lesson.index,
          time: lesson.time
        })),
        updated: updatedLessons.map(lesson => ({
          id: lesson.id,
          subject: lesson.subject,
          teacher: lesson.teacher,
          classroom: lesson.classroom,
          day: schedule.find(day =>
            day.lessons.some(l => l.id === lesson.id)
          )?.day || '',
          index: lesson.index,
          time: lesson.time
        })),
        deleted: deletedLessonIds
      };

      // Отправляем запрос на API
      const response = await fetch('/api/schedule/save', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          groupId: group,
          week: week,
          changes: changes
        }),
      });

      if (response.ok) {
        // Если сохранение успешно, очищаем списки изменений
        setAddedLessons([]);
        setUpdatedLessons([]);
        setDeletedLessonIds([]);

        setSaveSuccess(true);
        setTimeout(() => setSaveSuccess(false), 3000);
      } else {
        const errorData = await response.json();
        setError(errorData.message || 'Не удалось сохранить расписание');
      }
    } catch (err) {
      console.error('Ошибка при сохранении расписания:', err);
      setError('Ошибка при сохранении расписания. Пожалуйста, попробуйте позже.');
    } finally {
      setIsSaving(false);
    }
  };

  // Обновление временного занятия при редактировании
  const updateTempLesson = (field: keyof Lesson, value: any) => {
    if (tempLesson) {
      setTempLesson({ ...tempLesson, [field]: value });
    }
  };

  // Обновление времени занятия
  const updateLessonTime = (timeIndex: number) => {
    if (tempLesson) {
      setTempLesson({ ...tempLesson, time: lessonTimes[timeIndex] });
    }
  };

  // Обновление пользовательского времени занятия
  const updateCustomTime = (type: 'start' | 'end', value: string) => {
    if (tempLesson) {
      const updatedTime = { ...tempLesson.time };
      updatedTime[type] = value;
      setTempLesson({ ...tempLesson, time: updatedTime });
    }
  };

  // Форматирование названия кабинета
  const formatCabinet = (cabinet: string) => {
    if (cabinet.includes("дист.")) {
      return "Дистант";
    } else if(cabinet.includes("c.з.")) {
      return "Спортировный зал";
    } else {
      return `${cabinet} кабинет`;
    }
  }

  // В resetScheduleChanges добавляем сброс изменений
  const resetScheduleChanges = () => {
    setAddedLessons([]);
    setUpdatedLessons([]);
    setDeletedLessonIds([]);
  };

  // Сбрасываем отслеживание изменений при изменении группы или недели
  useEffect(() => {
    resetScheduleChanges();
  }, [group, week]);

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
        <span className="ml-3 text-gray-600">Загрузка расписания...</span>
      </div>
    );
  }

  if (error && !schedule.length) {
    return (
      <div className="flex flex-col justify-center items-center py-12">
        <div className="text-red-500 mb-2">
          <X className="w-8 h-8" />
        </div>
        <span className="text-red-500 text-center font-medium">{error}</span>
        <button
          onClick={() => {
            setError(null);
            setLoading(true);
            lessonService.getLessonsByGroup(group)
              .then(response => {
                if (response) {
                  const transformedSchedule = transformApiLessonsToSchedule(response);
                  setSchedule(transformedSchedule);
                } else {
                  setError('Не удалось загрузить расписание');
                }
              })
              .catch(err => {
                console.error('Ошибка при загрузке расписания:', err);
                setError('Ошибка при загрузке расписания. Пожалуйста, попробуйте позже.');
              })
              .finally(() => {
                setLoading(false);
              });
          }}
          className="mt-4 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
        >
          Попробовать снова
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Уведомление об ошибке */}
      <AnimatePresence>
        {error && (
          <motion.div
            className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4 flex items-center justify-between"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <span>{error}</span>
            <button
              onClick={() => setError(null)}
              className="text-red-500 hover:text-red-700"
            >
              <X className="w-5 h-5" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Уведомление об успешном сохранении */}
      <AnimatePresence>
        {saveSuccess && (
          <motion.div
            className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-4"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            Изменения успешно сохранены
          </motion.div>
        )}
      </AnimatePresence>

      {/* Редактор урока */}
      <AnimatePresence>
        {editingLesson && (
          <>
            <motion.div
              className="fixed inset-0 bg-black bg-opacity-50 z-40"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
            />
            <motion.div
              className="fixed inset-0 flex items-center justify-center p-4 z-50"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              <motion.div
                className="bg-white rounded-xl shadow-lg max-w-lg w-full p-4 md:p-6"
                initial={{ y: 10, opacity: 0, scale: 0.95 }}
                animate={{ y: 0, opacity: 1, scale: 1 }}
                exit={{ y: 10, opacity: 0, scale: 0.95 }}
                transition={{
                  type: "spring",
                  damping: 25,
                  stiffness: 300,
                  duration: 0.3
                }}
              >
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-medium text-gray-900">Редактирование занятия</h3>
                  <button
                    onClick={handleCancelEdit}
                    className="text-gray-500 hover:text-gray-700 p-1 rounded-full hover:bg-gray-100"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Предмет</label>
                    <select
                      value={tempLesson?.subject || ''}
                      onChange={(e) => updateTempLesson('subject', e.target.value)}
                      className="w-full p-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900"
                      disabled={loadingSubjects}
                    >
                      <option value="">Выберите предмет</option>
                      {loadingSubjects ? (
                        <option value="" disabled>Загрузка предметов...</option>
                      ) : subjects.length === 0 ? (
                        <option value="" disabled>Нет доступных предметов</option>
                      ) : (
                        subjects.map((subject) => (
                          <option key={subject} value={subject}>{subject}</option>
                        ))
                      )}
                    </select>
                    {/* Опция добавления нового предмета, если не найден в списке */}
                    {!loadingSubjects && tempLesson?.subject && !subjects.includes(tempLesson.subject) && (
                      <div className="mt-1 text-xs text-blue-600">
                        * Новый предмет, будет добавлен в систему
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Преподаватель</label>
                    <select
                      value={tempLesson?.teacher || ''}
                      onChange={(e) => updateTempLesson('teacher', e.target.value)}
                      className="w-full p-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900"
                      disabled={loadingTeachers}
                    >
                      <option value="">Выберите преподавателя</option>
                      {loadingTeachers ? (
                        <option value="" disabled>Загрузка преподавателей...</option>
                      ) : teachers.length === 0 ? (
                        <option value="" disabled>Нет доступных преподавателей</option>
                      ) : (
                        teachers.map((teacher) => (
                          <option key={teacher} value={teacher}>{teacher}</option>
                        ))
                      )}
                    </select>
                    {/* Опция добавления нового преподавателя, если не найден в списке */}
                    {!loadingTeachers && tempLesson?.teacher && !teachers.includes(tempLesson.teacher) && (
                      <div className="mt-1 text-xs text-blue-600">
                        * Новый преподаватель, будет добавлен в систему
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Аудитория</label>
                    <input
                      type="text"
                      value={tempLesson?.classroom || ''}
                      onChange={(e) => updateTempLesson('classroom', e.target.value)}
                      placeholder="Например: 301"
                      className="w-full p-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Время</label>
                    <div className="space-y-2">
                      <select
                        value={lessonTimes.findIndex((time: LessonTime) =>
                          time.start === tempLesson?.time.start && time.end === tempLesson?.time.end
                        )}
                        onChange={(e) => {
                          const timeIndex = Number(e.target.value);
                          if (timeIndex >= 0) {
                            updateLessonTime(timeIndex);
                          }
                        }}
                        className="w-full p-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900"
                      >
                        <option value="-1">Выберите время из списка или введите своё</option>
                        {lessonTimes.map((time: LessonTime, index: number) => (
                          <option key={index} value={index}>
                            {time.start} - {time.end}
                          </option>
                        ))}
                      </select>

                      <div className="flex gap-2 items-center mt-2">
                        <div className="flex-1">
                          <label className="block text-xs text-gray-500 mb-1">Начало</label>
                          <input
                            type="time"
                            value={tempLesson?.time.start || ''}
                            onChange={(e) => updateCustomTime('start', e.target.value)}
                            className="w-full p-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900"
                          />
                        </div>
                        <div className="flex items-center pt-5">—</div>
                        <div className="flex-1">
                          <label className="block text-xs text-gray-500 mb-1">Конец</label>
                          <input
                            type="time"
                            value={tempLesson?.time.end || ''}
                            onChange={(e) => updateCustomTime('end', e.target.value)}
                            className="w-full p-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-end space-x-3 mt-4">
                    <button
                      onClick={handleCancelEdit}
                      className="px-4 py-2 text-gray-700 hover:text-gray-900 transition-colors"
                    >
                      Отмена
                    </button>
                    <button
                      onClick={handleSaveLesson}
                      className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors flex items-center"
                    >
                      <Save className="w-4 h-4 mr-1" />
                      Сохранить
                    </button>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Добавление нового урока */}
      <AnimatePresence>
        {isAddingLesson && (
          <>
            <motion.div
              className="fixed inset-0 bg-black bg-opacity-50 z-40"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
            />
            <motion.div
              className="fixed inset-0 flex items-center justify-center p-4 z-50"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              <motion.div
                className="bg-white rounded-xl shadow-lg max-w-lg w-full p-4 md:p-6"
                initial={{ y: 10, opacity: 0, scale: 0.95 }}
                animate={{ y: 0, opacity: 1, scale: 1 }}
                exit={{ y: 10, opacity: 0, scale: 0.95 }}
                transition={{
                  type: "spring",
                  damping: 25,
                  stiffness: 300,
                  duration: 0.3
                }}
              >
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-medium text-gray-900">Добавление занятия</h3>
                  <button
                    onClick={handleCancelAdd}
                    className="text-gray-500 hover:text-gray-700 p-1 rounded-full hover:bg-gray-100"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Предмет</label>
                    <select
                      value={tempLesson?.subject || ''}
                      onChange={(e) => updateTempLesson('subject', e.target.value)}
                      className="w-full p-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900"
                      disabled={loadingSubjects}
                    >
                      <option value="">Выберите предмет</option>
                      {loadingSubjects ? (
                        <option value="" disabled>Загрузка предметов...</option>
                      ) : subjects.length === 0 ? (
                        <option value="" disabled>Нет доступных предметов</option>
                      ) : (
                        subjects.map((subject) => (
                          <option key={subject} value={subject}>{subject}</option>
                        ))
                      )}
                    </select>
                    {/* Опция добавления нового предмета, если не найден в списке */}
                    {!loadingSubjects && tempLesson?.subject && !subjects.includes(tempLesson.subject) && (
                      <div className="mt-1 text-xs text-blue-600">
                        * Новый предмет, будет добавлен в систему
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Преподаватель</label>
                    <select
                      value={tempLesson?.teacher || ''}
                      onChange={(e) => updateTempLesson('teacher', e.target.value)}
                      className="w-full p-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900"
                      disabled={loadingTeachers}
                    >
                      <option value="">Выберите преподавателя</option>
                      {loadingTeachers ? (
                        <option value="" disabled>Загрузка преподавателей...</option>
                      ) : teachers.length === 0 ? (
                        <option value="" disabled>Нет доступных преподавателей</option>
                      ) : (
                        teachers.map((teacher) => (
                          <option key={teacher} value={teacher}>{teacher}</option>
                        ))
                      )}
                    </select>
                    {/* Опция добавления нового преподавателя, если не найден в списке */}
                    {!loadingTeachers && tempLesson?.teacher && !teachers.includes(tempLesson.teacher) && (
                      <div className="mt-1 text-xs text-blue-600">
                        * Новый преподаватель, будет добавлен в систему
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Аудитория</label>
                    <input
                      type="text"
                      value={tempLesson?.classroom || ''}
                      onChange={(e) => updateTempLesson('classroom', e.target.value)}
                      placeholder="Например: 301"
                      className="w-full p-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Время</label>
                    <div className="space-y-2">
                      <select
                        value={lessonTimes.findIndex((time: LessonTime) =>
                          time.start === tempLesson?.time.start && time.end === tempLesson?.time.end
                        )}
                        onChange={(e) => {
                          const timeIndex = Number(e.target.value);
                          if (timeIndex >= 0) {
                            updateLessonTime(timeIndex);
                          }
                        }}
                        className="w-full p-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900"
                      >
                        <option value="-1">Выберите время из списка или введите своё</option>
                        {lessonTimes.map((time: LessonTime, index: number) => (
                          <option key={index} value={index}>
                            {time.start} - {time.end}
                          </option>
                        ))}
                      </select>

                      <div className="flex gap-2 items-center mt-2">
                        <div className="flex-1">
                          <label className="block text-xs text-gray-500 mb-1">Начало</label>
                          <input
                            type="time"
                            value={tempLesson?.time.start || ''}
                            onChange={(e) => updateCustomTime('start', e.target.value)}
                            className="w-full p-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900"
                          />
                        </div>
                        <div className="flex items-center pt-5">—</div>
                        <div className="flex-1">
                          <label className="block text-xs text-gray-500 mb-1">Конец</label>
                          <input
                            type="time"
                            value={tempLesson?.time.end || ''}
                            onChange={(e) => updateCustomTime('end', e.target.value)}
                            className="w-full p-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-end space-x-3 mt-4">
                    <button
                      onClick={handleCancelAdd}
                      className="px-4 py-2 text-gray-700 hover:text-gray-900 transition-colors"
                    >
                      Отмена
                    </button>
                    <button
                      onClick={handleSaveNewLesson}
                      className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors flex items-center"
                    >
                      <Save className="w-4 h-4 mr-1" />
                      Сохранить
                    </button>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Расписание */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 animate-fade-in">
        {schedule.map((day, dayIndex) => (
          <div
            key={day.day}
            className="bg-white p-3 md:p-4 rounded-lg shadow-sm border border-gray-100 hover:shadow-md transition-shadow"
          >
            <div className="flex items-center justify-between mb-3 pb-2 border-b border-gray-100">
              <h3 className="text-base md:text-lg font-medium text-gray-900 flex items-center">
                <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2 text-blue-500" />
                {day.day}
              </h3>
              <button
                onClick={() => handleAddLesson(dayIndex)}
                className="p-1 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-full transition-colors"
              >
                <Plus className="w-4 h-4 md:w-5 md:h-5" />
              </button>
            </div>

            {day.lessons.length === 0 ? (
              <div className="text-center py-6 text-gray-500 text-sm">
                Нет занятий
              </div>
            ) : (
              <div className="space-y-3">
                {day.lessons.map((lesson, lessonIndex) => (
                  <div
                    key={lesson.id}
                    className="p-2 md:p-3 border border-gray-100 rounded-lg hover:border-blue-100 hover:bg-blue-50 transition-colors relative group"
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="font-medium text-gray-900 text-sm md:text-base mb-1">
                          {lesson.index}. {lesson.subject}
                        </div>
                        <div className="text-gray-600 text-xs md:text-sm flex flex-col md:flex-row md:items-center">
                          <span className="flex items-center">
                            <Clock className="w-3 h-3 mr-1 text-gray-400" />
                            {lesson.time.start} - {lesson.time.end}
                          </span>
                          <span className="hidden md:inline mx-1.5">•</span>
                          <span>{formatCabinet(lesson.classroom)}</span>
                        </div>
                        <div className="text-gray-500 text-xs mt-1">
                          {lesson.teacher}
                        </div>
                      </div>
                      <div className="flex items-center space-x-1">
                        <button
                          onClick={() => handleEditLesson(dayIndex, lessonIndex)}
                          className="p-1 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-full transition-colors"
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteLesson(dayIndex, lessonIndex)}
                          className="p-1 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-full transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Кнопка сохранения */}
      <div className="fixed bottom-4 right-4 md:bottom-8 md:right-8 z-10">
        <button
          onClick={handleSaveSchedule}
          className="px-4 py-3 bg-blue-500 text-white rounded-full shadow-lg hover:bg-blue-600 transition-all hover:shadow-xl flex items-center"
        >
          <Save className="w-5 h-5 mr-2" />
          <span>Сохранить расписание</span>
        </button>
      </div>
    </div>
  );
}