import { api } from '../apiConfig';
import { ApiResponse, Lesson, GetLessonsRequest } from '../types';

/**
 * Service for lesson-related operations
 */
const lessonService = {
  /**
   * Get lessons for a specific group
   * @param params Parameters including session and group information
   * @returns Promise with list of lessons
   */
  getLessonsByGroup: async (group: string): Promise<ApiResponse<Lesson[]>> => {
    return api.post<ApiResponse<Lesson[]>>('/lesson/get', {
        group: group,
        session: ""
    });
  },
  
  /**
   * Get list of available lesson names for a group
   * @param groupName Group name to get lessons for
   * @param session Optional session data
   * @returns Promise with list of lesson names
   */
  getLessonList: async (groupName: string): Promise<ApiResponse<string[]>> => {
    return api.post<ApiResponse<string[]>>('/lesson/lessonList', {
      group: groupName,
      session: ""
    });
  },
  
  /**
   * Get list of available teachers for a group
   * @param groupName Group name to get teachers for
   * @param session Optional session data
   * @returns Promise with list of teacher names
   */
  getTeacherList: async (groupName: string): Promise<ApiResponse<string[]>> => {
    return api.post<ApiResponse<string[]>>('/lesson/teacherList', {
      group: groupName,
      session: ""
    });
  },
  
  /**
   * Create a new lesson
   * @param lesson Lesson data to create
   * @param session Optional session data
   * @returns Promise with created lesson
   */
  createLesson: async (lesson: Omit<Lesson, 'id'>, session: any = {}): Promise<ApiResponse<Lesson>> => {
    return api.post<ApiResponse<Lesson>>('/lesson/create', { lesson, session });
  },
  
  /**
   * Update an existing lesson
   * @param id Lesson ID to update
   * @param lesson Updated lesson data
   * @param session Optional session data
   * @returns Promise with updated lesson
   */
  updateLesson: async (id: string, lesson: Partial<Omit<Lesson, 'id'>>, session: any = {}): Promise<ApiResponse<Lesson>> => {
    return api.post<ApiResponse<Lesson>>('/lesson/update', { id, lesson, session });
  },
  
  /**
   * Delete a lesson
   * @param id Lesson ID to delete
   * @param session Optional session data
   * @returns Promise with success status
   */
  deleteLesson: async (id: string, session: any = {}): Promise<ApiResponse<void>> => {
    return api.post<ApiResponse<void>>('/lesson/delete', { id, session });
  }
};

export default lessonService; 